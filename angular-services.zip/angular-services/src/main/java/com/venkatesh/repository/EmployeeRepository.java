package com.venkatesh.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.venkatesh.model.Employee;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, String> {

	@Query("SELECT emp FROM Employee emp WHERE emp.lastRevision = "
			+ "com.venkatesh.constants.AngularConstants.LAST_REVISION_YES ")
	public List<Employee> findAll();

	public Employee findEmployeeById(String employeeId);

	List<Employee> findByLastRevisionAndIdIn(Character lastRevision, List<String> findAllActiveEmployees);

	Employee findByEmail(String email);

}

