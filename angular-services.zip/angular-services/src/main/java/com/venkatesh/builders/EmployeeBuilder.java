package com.venkatesh.builders;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.BeanUtils;

import com.venkatesh.dto.EmployeeDTO;
import com.venkatesh.model.Address;
import com.venkatesh.model.Employee;

public class EmployeeBuilder {


	public static EmployeeBuilder employeeBuilder() {
		return new EmployeeBuilder();
	}

	public List<EmployeeDTO> bindToEmployees(List<Employee> employeeList) {
		List<EmployeeDTO> employeeDtoList = new ArrayList<>();
		employeeList.stream().forEach(employee -> employeeDtoList.add(bindToEmployeeDto(employee)));
		return employeeDtoList;
	}

	public EmployeeDTO bindToEmployeeDto(Employee employee) {
		EmployeeDTO employeeDTO = new EmployeeDTO();
		employeeDTO.setId(employee.getId());
		employeeDTO.setName(employee.getName());
		employeeDTO.setEmail(employee.getEmail());
		employeeDTO.setCreateDate(employee.getCreateDate());
		employeeDTO.setCreateUser(employee.getCreateUser());
		employeeDTO.setModifyDate(employee.getModifyDate());
		employeeDTO.setModifyUser(employee.getModifyUser());
		employeeDTO.setLastRevision(employee.getLastRevision());
		return employeeDTO;
	}

	public Employee saveEmployee(EmployeeDTO employeeDto, Date date) {
		Employee employee = new Employee();		
		employee.setCreateUser(employeeDto.getEmail());
		employee.setCreateDate(date);
		employee.setId(UUID.randomUUID().toString());
		employee.setLastRevision('Y');
		employee.setEmail(employeeDto.getEmail());
		employee.setName(employeeDto.getName());
		employee.setModifyUser(null);
		employee.setAddress(saveAddress(employeeDto));
		return employee;
	}

	public List<Address> saveAddress(EmployeeDTO employeeDTO) {
		List<Address> addressList = new ArrayList<>();
		employeeDTO.getAddress().stream().forEach(employeeAddress -> {
			Address address = new Address();
			BeanUtils.copyProperties(employeeAddress, address);
			address.setId(UUID.randomUUID().toString());
			addressList.add(address);
		});
		return addressList;
	}
}
