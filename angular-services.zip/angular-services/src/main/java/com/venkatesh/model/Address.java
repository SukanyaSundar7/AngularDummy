package com.venkatesh.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "ADDRESS")
@Setter
@Getter
public class Address {
	@Id
	@Column(name = "ID")
	private String id;
	@Column(name = "HOUSER_NO")
	private String hNo;
	@Column(name = "STREET")
	private String street;
	@Column(name = "PINCODE")
	private String pincode;
	@Column(name = "STATE")
	private String state;
	@Column(name = "NATIONALITY")
	private String nationality;
	@Column(name = "PHONE_NUMBER")
	private String phoneNumber;
	
}
