package com.venkatesh.operation;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.venkatesh.builders.EmployeeBuilder;
import com.venkatesh.constants.AngularConstants;
import com.venkatesh.dto.AddressDTO;
import com.venkatesh.dto.EmployeeDTO;
import com.venkatesh.model.Address;
import com.venkatesh.model.Employee;
import com.venkatesh.repository.AddressRepository;
import com.venkatesh.repository.EmployeeRepository;

@Service
public class EmployeeOperation {

	@Autowired
	private EmployeeRepository employeeRepository;

	@Autowired
	private AddressRepository addressRepository;
	
	public List<EmployeeDTO> getAllEmployees() {
		List<EmployeeDTO> employeeDtoList = new ArrayList<>();
		employeeRepository.findAll().stream().forEach(employee -> employeeDtoList.add(convertToEmployeeDto(employee)));
		return employeeDtoList;
	}

	public EmployeeDTO getEmployee(String employeeId) {

		return convertToEmployeeDto(employeeRepository.findEmployeeById(employeeId));
	}

	public EmployeeDTO saveEmployee(EmployeeDTO employeedto) {
		Date date = new Date();
		Employee employee = employeeRepository.findByEmail(employeedto.getEmail());
		if (ObjectUtils.isEmpty(employee)) {
			employee = EmployeeBuilder.employeeBuilder().saveEmployee(employeedto, date);
			employee = employeeRepository.save(employee);
			
	}else {
			employee.setName(employeedto.getName());
			employee.setModifyUser(employeedto.getEmail());
			employee.setLastRevision(AngularConstants.LAST_REVISION_YES);
			employee.setModifyDate(date);
			employee = employeeRepository.save(employee);
		}
		return convertToEmployeeDto(employee);
	}

	public EmployeeDTO convertToEmployeeDto(Employee employee) {
		EmployeeDTO employeeDTO = new EmployeeDTO();
		employeeDTO.setId(employee.getId());
		employeeDTO.setName(employee.getName());
		employeeDTO.setEmail(employee.getEmail());
		employeeDTO.setCreateDate(employee.getCreateDate());
		employeeDTO.setCreateUser(employee.getCreateUser());
		employeeDTO.setModifyDate(employee.getModifyDate());
		employeeDTO.setModifyUser(employee.getModifyUser());
		employeeDTO.setLastRevision(employee.getLastRevision());
		convertToAddressDto(employee.getAddress(), employeeDTO);
		return employeeDTO;
	}

	private void convertToAddressDto(List<Address> addressList, EmployeeDTO employeeDTO) {
		List<AddressDTO> addressDtos = new ArrayList<>();
		addressList.stream().forEach(address-> {
			AddressDTO addressDTO = new AddressDTO();
			BeanUtils.copyProperties(address, addressDTO);
			addressDtos.add(addressDTO);
		});
		employeeDTO.setAddress(addressDtos);
	}

	public void deleteEmployee(List<String> employeeIdsToDeactive) {
		List<Employee> employeesToDeactivate = new ArrayList<>();
		List<Employee> activeEmployees = employeeRepository
				.findByLastRevisionAndIdIn(AngularConstants.LAST_REVISION_YES, employeeIdsToDeactive);
		activeEmployees.stream().forEach(employee -> {
			employee.setLastRevision(AngularConstants.LAST_REVISION_NO);
			employeesToDeactivate.add(employee);
		});
		employeeRepository.saveAll(employeesToDeactivate);
	}
}
