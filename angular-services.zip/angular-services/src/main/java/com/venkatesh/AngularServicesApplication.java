package com.venkatesh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AngularServicesApplication  {

	public static void main(String[] args) {
		SpringApplication.run(AngularServicesApplication.class, args);
	}

}
