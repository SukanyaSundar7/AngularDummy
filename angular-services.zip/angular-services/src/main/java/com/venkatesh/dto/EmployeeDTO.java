package com.venkatesh.dto;

import java.util.Date;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Setter
@Getter
public class EmployeeDTO {

	private String id;

	private String name;

	private String email;
	
	private Date createDate;
	
	private String createUser;
	
	private Date modifyDate;
	
	private String modifyUser;

	private Character lastRevision;
	
	private List<AddressDTO> address;


}
