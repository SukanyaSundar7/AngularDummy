package com.venkatesh.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class AddressDTO {

	private String id;
	private String hNo;
	private String street;
	private String pincode;
	private String state;
	private String nationality;
	private String phoneNumber;

}
