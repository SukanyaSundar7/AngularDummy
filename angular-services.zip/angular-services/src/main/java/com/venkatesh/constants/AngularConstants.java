package com.venkatesh.constants;

public final class AngularConstants {

	private AngularConstants() {
		// No Sonar
	}

	public static final Character LAST_REVISION_YES = 'Y';
	public static final Character LAST_REVISION_NO = 'N';
}
