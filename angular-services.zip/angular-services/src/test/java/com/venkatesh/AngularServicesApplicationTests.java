package com.venkatesh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AngularServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
