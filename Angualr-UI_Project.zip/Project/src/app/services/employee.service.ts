import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Employee } from './../models/employee'
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { AngularConstants } from '../constants/AngularConstants'

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  BASE_URL: string = AngularConstants.EMPLOYEE_URL;
  constructor(private httpClient: HttpClient) { }

  getEmployee(employeeId: string): Observable<Employee> {

    const parameters = { "employeeId": employeeId }
    return this.httpClient.get<Employee>(this.BASE_URL + '/employee', { params: parameters });
  }

  getEmployees(): Observable<Employee[]> {

    return this.httpClient.get<Employee[]>(this.BASE_URL + '/allemployees').
      pipe(catchError(this.handleError))
  }

  saveEmployee(employee: any): Observable<Employee> {
    const headers = { 'Content-Type': 'application/json' };

    return this.httpClient.post<Employee>(this.BASE_URL + '/save', employee, { headers }).
      pipe(catchError(this.handleError))
  }

  deleteEmployee(employeeId: string): Observable<any> {
    let options = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Accept': "text/plain"
      }),
      body: [employeeId]
    };

    return this.httpClient.delete<any>(this.BASE_URL + "/delete", options);
  }

  
  handleError(error: HttpErrorResponse) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // client-side error 
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // server-side error 
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    window.alert(errorMessage);
    Observable.throw(error.message);
    return throwError(errorMessage);
  }
}
