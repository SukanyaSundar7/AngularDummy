import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AllEmployeeComponent } from './employee-details/all-employee/all-employee.component';
import { AddEmployeeComponent } from './employee-details/add-employee/add-employee.component';
import { EditEmployeeComponent } from './employee-details/edit-employee/edit-employee.component';
import { ShowEmployeeComponent } from './employee-details/show-employee/show-employee.component';
import { NotFoundComponent } from './errors/not-found/not-found.component';
import { HomeComponent } from './bars/home/home.component';
import { AppComponent } from './app.component';
import { AddressComponent } from './employee-details/address/address.component';


const routes: Routes = [
  { path: '', redirectTo: '/app-home', pathMatch: 'full' },
  // {path: 'app-root',component: AppComponent},
  { path: 'app-home', component: HomeComponent, pathMatch:'full' },
  { path: 'addemployee', pathMatch: 'prefix', component: AddEmployeeComponent },
  { path: 'allemployees', component: AllEmployeeComponent  },
  { path: 'showemployee/:id', component: ShowEmployeeComponent ,
  children:[
    {path:'address',component:AddressComponent}
  ]
},
  { path: 'editemployee', component: EditEmployeeComponent },
  { path: "**", component: NotFoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
