export class Address {
    id: string;
    hNo: string;
    street: string;
    pincode: number;
    state: string;
    nationality: string;
    phoneNumber: string;
}