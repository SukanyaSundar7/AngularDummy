import { Address } from "./Address";

export class Employee {
    id: string;
    name: string;
    email: string;
    lastRevision: string;
    address: Address = new Address;
}
