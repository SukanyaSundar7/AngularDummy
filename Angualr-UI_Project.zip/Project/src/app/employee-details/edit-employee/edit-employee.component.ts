import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'editemployee',
  templateUrl: './edit-employee.component.html',
  styleUrls: ['./edit-employee.component.css']
})
export class EditEmployeeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
