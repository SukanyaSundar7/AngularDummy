import { Component, OnInit } from '@angular/core';

import { EmployeeService } from '../../services/employee.service';
import { Employee } from '../../models/employee';
import { Address } from '../../models/Address';

@Component({
  selector: 'addemployee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {
  
  employees: Employee[];
  constructor(private employeeService: EmployeeService) { }

  ngOnInit(): void {
    this.employeeService.getEmployees().subscribe(data =>this.employees=data);
  }
  message: string;
  save_Employee: Employee = new Employee();

  saveEmployee() {    
    console.log(this.saveEmployee);
    
    let employeeObj ={
      'name':this.save_Employee.name,
      'email':this.save_Employee.email,
      'address':[this.save_Employee.address]

    }
    return this.employeeService.saveEmployee(employeeObj)
      .subscribe(data => {
        console.log(data)
        if (data.name != null) {
          this.message = "User Activated"
          this.employees.push(data);
          console.log(this.employees.length)
          this.clearValues(this.save_Employee);
        }
      },
        (error) => {
          console.log(error)
        })
  }
  clearValues(save_Employee:Employee):void{    
    save_Employee.name='';
    save_Employee.email='';
  }
}
