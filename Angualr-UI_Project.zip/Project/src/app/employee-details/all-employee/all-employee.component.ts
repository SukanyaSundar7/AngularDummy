import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../../services/employee.service';
import { Employee } from '../../models/employee';
import { NgxSpinnerService } from 'ngx-spinner';
import { ActivatedRoute, Router, ParamMap } from '@angular/router';

@Component({
  selector: 'allemployees',
  templateUrl: './all-employee.component.html',
  styleUrls: ['./all-employee.component.css']
})
export class AllEmployeeComponent implements OnInit {
  isEditable: boolean = false;
  message: string;
  employees: Employee[];
  employee: Employee;
  selectedId: string;
  constructor(private employeeService: EmployeeService, private sprinnerService: NgxSpinnerService,
    private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.sprinnerService.show();
    this.employeeService.getEmployees().
    subscribe((data) => {        
      this.employees = data;
      this.sprinnerService.hide();
    }
    );
      
    this.route.paramMap.subscribe((params: ParamMap) => {
      this.selectedId = params.get('id');
      console.log(this.selectedId)
    });
  }

  getEmployee() {
    return this.employeeService.getEmployee('454').
      subscribe((data) => this.employee = data);
  }

  deleteEmployee(employee: Employee) {
    this.sprinnerService.show('Record Deleting');
    console.log("Delete Employee");
    console.log(employee);
    this.employees.splice(this.employees.indexOf(employee), 1);
    this.employeeService.deleteEmployee(employee.id)
      .subscribe((data) => {
        console.log(data)
        this.sprinnerService.hide();
      }, (error) => {
        console.log(error)
      })

  }

  editEmployee(employee: Employee) {
    console.log("Edit Employee");
    console.log(employee);
    this.employeeService.saveEmployee(employee)
      .subscribe((data) => console.log('Success'))
    this.isEditable = false;
  }

  showEmployee(employee: Employee) {
   this.router.navigate(['/showemployee', employee.id]);
  // this.router.navigate([employee.id],{relativeTo:this.route})
  }
  selected(employee: Employee) {

    return this.selectedId === employee.id;
  }
}



