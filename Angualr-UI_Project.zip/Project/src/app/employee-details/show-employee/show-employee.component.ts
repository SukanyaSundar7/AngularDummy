import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { EmployeeService } from '../../services/employee.service';
import { Employee } from '../../models/employee';

@Component({
  selector: 'showemployee',
  templateUrl: './show-employee.component.html',
  styleUrls: ['./show-employee.component.css']
})
export class ShowEmployeeComponent implements OnInit {
  selectedId: string;
  employee: Employee;
  constructor(private route: ActivatedRoute, private employeeService: EmployeeService,
    private router: Router) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe((params: ParamMap) => {
      let employeeId = params.get('id');
      this.selectedId = employeeId;
      this.employeeService.getEmployee(employeeId)
        .subscribe((data) => this.employee = data)
    });
  }

  backToAllEmployee() {
    //Obsolute Navigation
    this.router.navigate(['allemployees', { 'id': this.selectedId }]);
    // this.router.navigate(['../',{id:this.selectedId}],{relativeTo:this.route})
  }
  showAddress() {
    this.router.navigate(['/address']);
  }
}
