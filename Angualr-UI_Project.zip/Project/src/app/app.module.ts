import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmployeeService } from './services/employee.service';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { AddEmployeeComponent } from './employee-details/add-employee/add-employee.component';
import { EditEmployeeComponent } from './employee-details/edit-employee/edit-employee.component';
import { FooterComponent } from './footer/footer.component';
import { NgxSpinnerModule } from 'ngx-spinner';

import { AllEmployeeComponent } from './employee-details/all-employee/all-employee.component';
import { NotFoundComponent } from './errors/not-found/not-found.component';
import { HomeComponent } from './bars/home/home.component';
import { ShowEmployeeComponent } from './employee-details/show-employee/show-employee.component';
import { AddressComponent } from './employee-details/address/address.component';
@NgModule({
  declarations: [
    AppComponent,
    AddEmployeeComponent,
    FooterComponent,
    EditEmployeeComponent,
    AllEmployeeComponent,
    NotFoundComponent,
    HomeComponent,
    ShowEmployeeComponent,
    AddressComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    NgxSpinnerModule
  ],
  providers: [EmployeeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
