export class AngularConstants {

    static readonly EMPLOYEE_URL: string = "http://localhost:9292/api/app/angular/v1/employee";
}